from botocore.response import StreamingBody

# aliasing as 3.7 is no longer supported but unsure if anyone took a dependency on it (hyrum's law)
PowertoolsStreamingBody = StreamingBody
